#include "serialportopenclose.h"
#include "./ui_serialportopenclose.h"

SerialPortOpenClose::SerialPortOpenClose(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::SerialPortOpenClose)
{
    ui->setupUi(this);

    // Serial port object
    port = new QSerialPort();

    // Signal & slots
    connect(ui->btnOpen, &QPushButton::clicked, this, &SerialPortOpenClose::openSerialPort);
    connect(ui->btnClose, &QPushButton::clicked, this, &SerialPortOpenClose::closeSerialPort);
}

SerialPortOpenClose::~SerialPortOpenClose()
{
    delete ui;
}

void SerialPortOpenClose::openSerialPort()
{
    qDebug() << "Open serial port";
    qDebug() << ui->editPortFile->text();
    port->setPortName(ui->editPortFile->text());
    port->setBaudRate(QSerialPort::Baud9600);
    port->setDataBits(QSerialPort::Data8);
    port->setParity(QSerialPort::NoParity);
    port->setStopBits(QSerialPort::OneStop);
    port->setFlowControl(QSerialPort::NoFlowControl);

    if(!port->isOpen())
    {
        qDebug() << "Openning...";
        port->open(QIODevice::ReadWrite);
        ui->editPortFile->setEnabled(false);
        ui->btnOpen->setEnabled(false);
        ui->btnClose->setEnabled(true);
    }
    else
        qDebug() << "Already opened...";
}

void SerialPortOpenClose::closeSerialPort()
{
    qDebug() << "Close serial port";
    if(port->isOpen())
    {
        port->close();
        ui->editPortFile->setEnabled(true);
        ui->btnOpen->setEnabled(true);
        ui->btnClose->setEnabled(false);
    }
}
