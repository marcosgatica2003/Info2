#ifndef SERIALPORTOPENCLOSE_H
#define SERIALPORTOPENCLOSE_H

#include <QWidget>
#include <QDebug>
#include <QSerialPort>

QT_BEGIN_NAMESPACE
namespace Ui {
class SerialPortOpenClose;
}
QT_END_NAMESPACE

class SerialPortOpenClose : public QWidget
{
    Q_OBJECT

public:
    SerialPortOpenClose(QWidget *parent = nullptr);
    ~SerialPortOpenClose();

private:
    Ui::SerialPortOpenClose *ui;

    // Puntero a objeto SerialPort
    QSerialPort *port;

private slots:
    void openSerialPort();
    void closeSerialPort();
};
#endif // SERIALPORTOPENCLOSE_H
