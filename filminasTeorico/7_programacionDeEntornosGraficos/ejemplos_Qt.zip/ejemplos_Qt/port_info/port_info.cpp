#include <QCoreApplication>
#include <QTextStream>
#include <QSerialPortInfo>
#include <QList>

int main(int argc, char *argv[])
{
    QCoreApplication app(argc, argv);
    QTextStream out(stdout);

    // From: https://doc.qt.io/qt-6/qserialportinfo.html
    QList<QSerialPortInfo> port_info = QSerialPortInfo::availablePorts();

    out << "# of serial ports: " << port_info.count() << Qt::endl;
    for(int i = 0; i < port_info.size(); i++) 
    {
        out << "\n"
            << "Port: " << port_info[i].portName() << "\n"
            << "Location: " << port_info[i].systemLocation() << "\n"
            << "Description: " << port_info[i].description() << "\n"
            << "Manufacturer: " << port_info[i].manufacturer() << "\n"
            << "Serial number: " << port_info[i].serialNumber() << "\n"
            << "Vendor Identifier: "
            << (port_info[i].hasVendorIdentifier()
                    ? QByteArray::number(port_info[i].vendorIdentifier(), 16)
                    : QByteArray()) << "\n"
            << "Product Identifier: "
            << (port_info[i].hasProductIdentifier()
                    ? QByteArray::number(port_info[i].productIdentifier(), 16)
                    : QByteArray()) << "\n";
    }
    out << Qt::endl;
    return 0;
}
