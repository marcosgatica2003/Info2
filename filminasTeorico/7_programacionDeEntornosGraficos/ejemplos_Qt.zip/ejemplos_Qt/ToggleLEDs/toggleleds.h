#ifndef TOGGLELEDS_H
#define TOGGLELEDS_H

#include <QWidget>
#include <QDebug>
#include <QSerialPort>

QT_BEGIN_NAMESPACE
namespace Ui {
class ToggleLEDs;
}
QT_END_NAMESPACE

class ToggleLEDs : public QWidget
{
    Q_OBJECT

public:
    ToggleLEDs(QWidget *parent = nullptr);
    ~ToggleLEDs();

private:
    Ui::ToggleLEDs *ui;

    // Puntero a objeto SerialPort
    QSerialPort *port;

private slots:
    void portOpen();
    void portClose();
    void portSendV();
    void portSendA();
    void portSendR();
};
#endif // TOGGLELEDS_H
