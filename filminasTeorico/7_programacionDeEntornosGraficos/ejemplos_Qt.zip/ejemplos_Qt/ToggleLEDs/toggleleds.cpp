#include "toggleleds.h"
#include "./ui_toggleleds.h"

ToggleLEDs::ToggleLEDs(QWidget *parent)
    : QWidget(parent)
    , ui(new Ui::ToggleLEDs)
{
    ui->setupUi(this);

    // SerialPort object
    port = new QSerialPort();

    // Setting default values.
    port->setBaudRate(QSerialPort::Baud9600);
    port->setDataBits(QSerialPort::Data8);
    port->setParity(QSerialPort::NoParity);
    port->setStopBits(QSerialPort::OneStop);
    port->setFlowControl(QSerialPort::NoFlowControl);

    // Connect signals&slots
    connect(ui->btnOpen, &QPushButton::clicked, this, &ToggleLEDs::portOpen);
    connect(ui->btnClose, &QPushButton::clicked, this, &ToggleLEDs::portClose);
    connect(ui->btnSendV, &QPushButton::clicked, this, &ToggleLEDs::portSendV);
    connect(ui->btnSendA, &QPushButton::clicked, this, &ToggleLEDs::portSendA);
    connect(ui->btnSendR, &QPushButton::clicked, this, &ToggleLEDs::portSendR);
}

ToggleLEDs::~ToggleLEDs()
{
    delete ui;
}

void ToggleLEDs::portOpen()
{
    port->setPortName(ui->editPort->text());
    if(!port->isOpen())
    {
        qDebug() << "Openning...";
        port->open(QIODevice::ReadWrite);
        ui->editPort->setEnabled(false);
        ui->btnOpen->setEnabled(false);
        ui->btnClose->setEnabled(true);
    }
    else
        qDebug() << "Already opened...";
}

void ToggleLEDs::portClose()
{
    qDebug() << "Close serial port";
    if(port->isOpen())
    {
        port->close();
        ui->editPort->setEnabled(true);
        ui->btnOpen->setEnabled(true);
        ui->btnClose->setEnabled(false);

    }
}

void ToggleLEDs::portSendV()
{
    if(port->isOpen())
    {
        qDebug() << "V";
        port->write("v", 1);
    }
}

void ToggleLEDs::portSendA()
{
    if(port->isOpen())
    {
        qDebug() << "A";
        port->write("a", 1);
    }
}

void ToggleLEDs::portSendR()
{
    if(port->isOpen())
    {
        qDebug() << "R";
        port->write("r", 1);
    }
}
