#ifndef HOLA_H
#define HOLA_H

void hola(const char *nombre);

#endif

