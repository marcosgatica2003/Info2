#include <stdio.h>
#include "hola.h"

void hola(const char *nombre)
{
  printf("Hola, %s\n", nombre);
}

