#ifndef UTIL_H
#define UTIL_H

void setBit(unsigned int *num, unsigned int bit);
void resetBit(unsigned int *num, unsigned int bit);
unsigned int getBit(unsigned int num, unsigned int bit);

#endif