#include "util.h"

void setBit(unsigned int *num, unsigned int bit) {
    *num |= (1 << bit);
}

void resetBit(unsigned int *num, unsigned int bit) {
    *num &= ~(1 << bit);
}

unsigned int getBit(unsigned int num, unsigned int bit) {
    return (num >> bit) & 1;
}

