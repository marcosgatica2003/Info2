#include <stdio.h>
#include <string.h>
#include "util.h"

// Definición de la macro para el texto encriptado
#ifndef T_ENCRIP
#define T_ENCRIP "Buff{ qx euq xqq qx yqzgajq"
#endif

int main() {
    char text[] = T_ENCRIP;
    unsigned int caracter, bit4, bit2;

    printf("Encrypted text: %s\n", text);
    
    for (int i = 0; i < strlen(text); i++) {
     caracter = (unsigned int) text[i];
     bit4 = getBit(caracter, 4);
     bit2 = getBit(caracter, 2);
                
     if(bit2) setBit(&caracter, 4);
     else resetBit(&caracter, 4);
        
     if(bit4) setBit(&caracter, 2);
     else resetBit(&caracter, 2);
        
     text[i] = (char) caracter;
    }
    
    printf("Decrypted text: %s\n", text);
    return 0;
}